#include "stm32f4xx.h"


#ifndef INC_TIM_H_
#define INC_TIM_H_

	void tim2_1hz_init(void);
	void tim_delay(void);

#endif
