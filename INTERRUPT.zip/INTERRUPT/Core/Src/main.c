#include "stm32f4xx.h"

void LED_ON(void);
void SWITCH_INITIALIZATION(void);
void EXTI15_10_IRQ(void);
void EXTI_CALLBACK(void);



int main()
{
	LED_ON();

	SWITCH_INITIALIZATION();

	EXTI15_10_IRQ();

	EXTI_CALLBACK();
}

void LED_ON(void)
{
	RCC-> AHB1ENR |=(1<<0);		//ENABLING GPIOA
	GPIOA-> MODER =0;			//TO CLEAN
	GPIOA-> MODER |=(1<<10);	//OUTPUT MODE FOR PIN 5
}
void SWITCH_INITIALIZATION(void)
{
	__disable_irq();			//DISABLE GLOBAL INTERRUPT
	RCC->AHB1ENR |=(1<<3);		//ENABLING THE GPIOC
	GPIOC->MODER = 0;			//TO CLEAN
	GPIOC->MODER = 0;			//TO SET GPIOC PIN 13 TO INPUT MODE
	RCC->APB2ENR |=(1<<14);		//TO ENR THE SYSCFG
	SYSCFG->EXTICR[3] |=(1<<5);	//TO ENR 13 PIN IN GPIOC
	EXTI->IMR |=(1<<13);		//TO UNMASK THE PIN13
	EXTI->FTSR |=(1<<13);		//TO EN FALLING TRRIGER FOR 13-PIN
	NVIC_EnableIRQ(EXTI15_10_IRQn); //
	__enable_irq();				//enable global interrupt
}

void EXTI15_10_IRQ(void)
{
	if(EXTI->PR &(1<<13)!=0)
	{
		EXTI->PR|=(1<<13); 		//EXTI->PR HAS SET TO BE 1
		EXTI_CALLBACK();
	}
}
void EXTI_CALLBACK(void)
 {
	GPIOA->ODR ^=(1<<5);
 }

