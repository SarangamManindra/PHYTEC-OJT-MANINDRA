#include "ext.h"
#include "stm32f4xx.h"
void pc13_exti_init(void)
{
	__disable_irq();

	RCC->AHB1ENR |=GPIOCEN;

	GPIOC->MODER &=~(1U<<26);
	GPIOC->MODER &=~(1U<<27);


	RCC->APB2ENR |=SYSCFGEN;

	SYSCFG->EXTICR[3] |=(1U<<5);

	EXTI->IMR |=(1U<<13);

	EXTI->FTSR |=(1U<<13);

	NVIC_EnableIRQ(EXTI15_10_IRQn);

	__enable_irq();

}



static void exti_callback(void)
{
	printf("BTN Pressed...\n\r");
	GPIOA->ODR ^=LED;
}


void EXTI15_10_IRQHandler(void)
{
	if((EXTI->PR & LINE13)!=0)
	{
		EXTI->PR |=LINE13;
		//Do something...
		exti_callback();
	}
}
